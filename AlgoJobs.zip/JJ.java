package AlgoJobs;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class JJ {
	static int n;
	static int[][] data;
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));

		StringTokenizer st = new StringTokenizer(br.readLine());

		int n = Integer.parseInt(st.nextToken());
		int r = Integer.parseInt(st.nextToken());

		data = new int[n][2];
		String first = "a";
		for(int i=0;i<n;i++) {
			data[i][0] = first.charAt(0)+i;
			data[i][1] = -1;
		}
		//		makeAnswer(0);
		int x=0;
		for(int k=0;k<r;k++) {
			for(int i=0;i<n;i++) {
				bw.write(Character.toString((char)data[i][0]));
				for(int j=0;j<n;j++) {
					bw.write(Character.toString((char)data[j][0]));
				}
				bw.newLine();
			}
		}

		//		for(int i=0;i<n;i++) {			
		//			for(int j=0;j<n;j++) {				
		//				if(i != j) {
		//					bw.write(Character.toString((char)data[i]));
		//					bw.write(Character.toString((char)data[j]));
		//					bw.newLine();
		//				}
		//			}
		//		}

		bw.flush();
	}
	//	private static String makeAnswer(int x) {
	//		for(int i=0;i<n;i++) {
	//			return
	//		}
	//		
	//	}

}

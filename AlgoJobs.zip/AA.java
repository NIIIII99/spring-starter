package AlgoJobs;

public class AA {
	public static void main(String[] args) {
		System.out.println("Hello");
		System.out.println("Algorithm");
		System.out.println("LABS!");
	}
}
